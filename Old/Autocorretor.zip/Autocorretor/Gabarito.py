def GEX01():
    return [1,2,3]

def GEX02():
    return True

def GEX03():
    return 2
