def EX01():
    return [1,2,4]
def EX02():
    return True
def EX03():
    return 2
