def EX01():
    return [1,2,3]
def EX03():
    return 2
